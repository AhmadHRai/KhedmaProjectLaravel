<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNodesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('nodes', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable();
            $table->string('secondry_title')->nullable();
            $table->text('summary')->nullable();
            $table->text('source')->nullable();
            $table->longText('body')->nullable();
            $table->text('keywords')->nullable();
            $table->text('path_img')->nullable();
            $table->text('img_discr')->nullable();
            $table->integer('status');
            $table->text('path_pdf')->nullable();
            $table->integer('orders');
            $table->integer('top');
            $table->text('publish_date');
            $table->text('slug')->nullable();
            $table->integer('statistics');
            $table->integer('rss')->nullable();
            $table->string('user_id_edit');
            $table->unsignedInteger('node_type_id');
            $table->foreign('node_type_id')->references('id')->on('node_types')->onUpdate('cascade')->onDelete('cascade');
            $table->unsignedInteger('category_id');
            $table->foreign('category_id')->references('id')->on('categories')->onUpdate('cascade')->onDelete('cascade');
            $table->unsignedInteger('user_id');
            $table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('nodes');
    }
}
