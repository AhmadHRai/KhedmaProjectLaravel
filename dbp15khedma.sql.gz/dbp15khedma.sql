-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2022 at 12:51 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbp15khedma`
--

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img_path` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orders` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`id`, `title`, `body`, `img_path`, `orders`, `type`, `status`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'اعلان 1', 'اعلان 1', 'img_1663511108.jpg', 1, 1, 1, 1, '2022-01-03 08:02:48', '2022-09-18 11:25:08'),
(2, 'lkkkkkk', 'l', NULL, 9, 3, 1, 1, '2022-01-03 08:03:32', '2022-01-03 08:03:32'),
(3, 'اعلان 2', 'اعلان 2', 'img_1663511117.jpg', 2, 1, 1, 10, '2022-09-07 08:27:10', '2022-09-18 11:25:17');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `discription` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phototable_id` int(11) DEFAULT NULL,
  `phototable_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mainsettings`
--

CREATE TABLE `mainsettings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone2` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address2` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mainsettings`
--

INSERT INTO `mainsettings` (`id`, `name`, `phone`, `phone2`, `email`, `description`, `keywords`, `address`, `address2`, `created_at`, `updated_at`) VALUES
(1, 'khedma application', '01676767', '71544545', 'khedma@gmail.com', 'khedma application to provide a community service to facilitate the search for workers and provide their services', 'khedma application', 'yemen', 'sanaa', '2021-07-24 17:54:59', '2022-09-20 13:06:38');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2022_05_10_000000_create_users_table', 1),
(2, '2022_05_10_100000_create_password_resets_table', 1),
(8, '2022_05_11_150214_create_files_table', 2),
(9, '2022_05_16_105628_create_cotegories_table', 2),
(10, '2022_05_16_105714_create_node_types_table', 2),
(15, '2022_05_22_181909_create_nodes_table', 3),
(16, '2022_05_24_131239_create_msgs_table', 4),
(17, '2022_05_24_135643_create_ads_table', 5),
(18, '2022_05_24_173218_create_mainsettings_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `msgs`
--

CREATE TABLE `msgs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `cases` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('hadeel@admin.com', '$2y$10$dVstEas3IDNWn/rmalkIPOsGxG8P1OVM1JYiiOiY.Z0xKz4/hBeuG', '2021-07-19 11:14:26'),
('admin@admin.com', '$2y$10$WdAJ9YU5M77inomlmaKTZ.1m9EhSbdyi3eu.2rbHYt6TIUtR0/FyS', '2021-07-19 11:15:32');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) DEFAULT NULL,
  `name` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `type_jobs`
--

CREATE TABLE `type_jobs` (
  `id` int(11) NOT NULL,
  `name` varchar(259) NOT NULL,
  `path` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `type_jobs`
--

INSERT INTO `type_jobs` (`id`, `name`, `path`, `created_at`, `updated_at`) VALUES
(1, 'الكهربائي', 'img_1663181572.jpg', NULL, '2022-09-14 15:52:52'),
(2, 'النظافة', 'img_1663181583.jpg', NULL, '2022-09-14 15:53:03'),
(3, 'السباكين', 'img_1663181593.jpg', NULL, '2022-09-14 15:53:13'),
(4, 'المرنجين', 'img_1663181600.jpg', NULL, '2022-09-14 15:53:20');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path_card` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type_job_id` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `booking` int(11) DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `phone`, `address`, `path`, `path_card`, `status`, `user_id`, `type_job_id`, `rating`, `booking`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'ds', 'ds@ds.com', '2021-12-28 18:05:57', '$2y$10$YzdcPlrh5REi0wiTQ1mmD.TdGUv1syqruNBLnNbsmi9NYX/wob.Ia', '7711771771', NULL, '0', NULL, 0, 1, 1, 12, NULL, 1, '7pRCdrkhVIE1T1aj1dKiXCKQYE4XjA2lIBE09SlgJqRKH6mDhMYIUvnTJI4o', '2021-07-14 18:05:30', '2021-12-29 02:14:16'),
(10, 'admin', 'admin@admin.com', '2022-01-07 21:00:00', '$2y$10$GPepii5HvM6ZnxNcCkNpSOLKvKySrG4Hhn.mrVXODSMJGYmA4ZC8u', '7711771771', NULL, '0', NULL, 1, 1, 2, 8, 1, 1, 'x1XrLYFLXsBYDqN7xvzfzfu7eHly6pGeSbQBf43psVFTzP4RuUyX5hsLqvCv', '2021-12-29 02:15:24', '2022-09-24 11:54:37'),
(41, 'محمد امين', 'a17@admin.com', '2022-01-07 21:00:00', '$2y$10$lb9IAy5tpOMyyLfseBSWauX6ffYVLS9waoq.FHKVns3TgjkRflpaC', NULL, 'اليمن حي شميلة شارع تعز', 'img_1663519213.jpg', NULL, 1, 1, 1, 5, 1, 2, 'dyYJ8oLERe8vPN0ZA1j7neWqfZXbo1PtSh4r77HGXk9pgD33rJb5vFdmabwz', '2022-09-11 16:40:39', '2022-09-18 13:47:58'),
(42, 'a18', 'a18@admin.com', '2022-01-07 21:00:00', '$2y$10$FyCwg1lzd//E.zN9knvuX.9hm3meUgH0A87VL/jCGmmn6gEYJLcmm', '7711771771', 'sanaa', '0', NULL, 1, 1, 1, 88, NULL, 2, '7jD3YqhmnYLSY7xcPM1bnouTbnaNWpBhJEittMYvj5nYYCZKVDSjMHaSP3gw', '2022-09-11 16:46:28', '2022-09-11 16:46:28'),
(43, 'a19', 'a19@admin.com', '2022-01-07 21:00:00', '$2y$10$10vfbF3CAa.FWr7fTvWhheWCNvKCbMBueu9vsl6TnPfzROI8vfSTa', '7711771771', 'sanaa', '0', NULL, 1, 1, 1, 22, NULL, 2, 'MGDYgcLJ24vHDhFxBI4Q1Jpk7OhNdKo8HqmKyWaTLleI5yM8NVnnsTVZvNVS', '2022-09-11 16:48:44', '2022-09-11 16:48:44'),
(44, '434343', 'adm2323in@admin.com', '2022-01-07 21:00:00', '$2y$10$aGvWQldB39oLgkWS957HCexJg4H60fZBHQB4v45.I5cNNLlMic1Kq', '12121212', '12121212', '', NULL, 1, 10, NULL, 1, NULL, 1, 'loog5XXwsWFHsu9jk0WbEKRf0aw3KZzoXoCIc9iIppzmDr4Iwh4m4jGEwpgS', '2022-09-14 15:49:18', '2022-09-14 15:49:18'),
(45, '23232323', 'a7000700232302@gmail.com', NULL, '$2y$10$2uaK3qlym8frjMCAF8Gbn.ayXTiIaajZBNjsSsgGCzYXkipbtV4dq', '23232323', NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, 3, 't7LohgyBqp7oYzWy3pPblRjVT6R8VGJcFYgFmKZ6Ehcd5vtXNYYUrVMZXHOJ', '2022-09-14 16:27:44', '2022-09-18 10:42:59'),
(46, 'a12', 'a12@admin.com', '2022-01-07 21:00:00', '$2y$10$nrZiUgNvM7KHfJh09a1ug.xmoMENviExglLoA3MnT9TaFMMO55VkC', '7711771771', 'sanaa', '0', NULL, 1, 1, 1, 0, NULL, 3, 'BAqEPiNG72n6jjmgmCOMZyWVuBXmmTZtRifKaa2bmvyH9TGFIy5nBtOK8ueo', '2022-09-18 10:29:01', '2022-09-18 10:29:01'),
(47, 'a13', 'a13@admin.com', '2022-01-07 21:00:00', '$2y$10$vFJ1/Liw3BDAchfBg2asKu3wHwHmLDPRaFpfVoyt7Ax758SrGBfNS', '7711771771', 'sanaa', 'img_1663508652.jpg', NULL, 1, 1, 1, 0, 0, 3, 'fJPp6KmaYz0sJxd4W3SV2xm4EkUO8lmphtL951Hq0OEmkcyvAsLXqWRTZou0', '2022-09-18 10:44:12', '2022-09-18 10:44:12'),
(58, 'a20', 'a20@admin.com', '2022-01-07 21:00:00', '$2y$10$LGi4.HwrHLsIXilhEphh8u7KlR7HJ/Tn0j8QxGOP1Uk2H.41PU4wW', '7711771771', 'sanaa', '0', NULL, 1, 1, 1, 0, 0, 3, 'qeDnMu77X5h3iie5WfNMOpnan4brCFlFmmVuyi4OjvMk50SCImVL436Q3GcA', '2022-09-21 17:12:10', '2022-09-21 17:12:10'),
(59, 'a21', 'a21@admin.com', '2022-01-07 21:00:00', '$2y$10$HWZ2PtMAu/zqGHKDIWwJsOro3KAbRC2Xdigw5MWQF9bPL5TeKzOlS', '7711771771', 'sanaa', '0', NULL, 1, 1, 1, 0, 0, 3, 'rTcfIzo0iTOGTF3S5wPcjwcerWhApcHxS980HDsMwRIU1s76E4XMaSQsd9eD', '2022-09-21 17:12:30', '2022-09-21 17:12:30'),
(61, 'a22', 'a22@admin.com', '2022-01-07 21:00:00', '$2y$10$R3k7hFLeXFSJ8tYR4hMDueaWloXGg6T1QJI5DHslsnkIVA62EAUGS', '7711771771', 'sanaa', '0', NULL, 1, 1, 1, 0, 0, 3, 'k9sqYRbw2Fse7Jbx60VGuvqHL15evukcsuVDo9d0550YpbZDx2bGKMNYGlOI', '2022-09-21 17:14:48', '2022-09-21 17:14:48'),
(62, 'a23', 'a23@admin.com', '2022-01-07 21:00:00', '$2y$10$cNE5u09yX8I1DGhwwfB0JOtyI73WbEWqCU33Aznax9nTHgs.Zpdha', '7711771771', 'sanaa', '0', NULL, 1, 1, 1, 0, 0, 3, 'hikoLX0iAEEcdlV4vycMBUza6CcGXWs5PKb7YXUTMxGwisEqt5JsAmg7MHXA', '2022-09-24 07:42:22', '2022-09-24 07:42:22'),
(63, 'a24', 'a24@admin.com', '2022-01-07 21:00:00', '$2y$10$GXEDXOeIKGSLdGLhIE6dGu1qXoGVxM4qSc/lmkVVSd.h2RYa73LdW', '7711771771', 'sanaa', '0', NULL, 1, 1, 1, 0, 0, 3, 'oY6q74ZCyfiAaMR1k5noNR5gTj9R1OxKbLDPySuJOvn5Hyw6pH8wHK7uWgaF', '2022-09-24 07:47:07', '2022-09-24 07:47:07'),
(67, 'a25', 'a25@admin.com', '2022-01-07 21:00:00', '$2y$10$H5tG9VhWtjSjH4LppOwPA.OFpvRCOoTdNzKRqTFLjYpvn/HjSnXDi', '7711771771', 'sanaa', '0', NULL, 1, 1, 1, 0, 0, 3, 'XS8HJ27ZjwJ1HfGuUACu3EZGpCVIKmMf8slvCvkWllqEtQc5S9ZjmSwuwqN3', '2022-09-24 08:02:01', '2022-09-24 08:02:01'),
(68, 'a26', 'a26@admin.com', '2022-01-07 21:00:00', '$2y$10$QCyy4bEIWOzNJebtQnFyJ.zykYydA4SPVr8oWSC7npWZWXVoonhNy', '7711771771', 'sanaa', 'img_1664025702.jpg', 'img_1664025703.jpg', 1, 1, 1, 0, 0, 3, 'wPmHwPHZW7zIC1o9aXRIpBMXfsUasxqtusK8FjlNFHLWh2cCrVRYIoqXFTOx', '2022-09-24 10:21:43', '2022-09-24 10:21:43'),
(69, 'a27', 'a27@admin.com', '2022-01-07 21:00:00', '$2y$10$/qS9rNARcCl2VnErL0lYm.PhXUPpop.KCQxkZ2xGiwWfIJ55jkq3S', '7711771771', 'sanaa', 'img_1664026328.jpg', 'img_1664026328.jpg', 1, 1, 1, 0, 0, 3, 'k1dnmx8Tgv5SD0d5OUiaOflhdBeexT2PfMTJOsD5ANgoXQ4ZQ7sptmmc3tQ9', '2022-09-24 10:32:08', '2022-09-24 10:32:08'),
(70, 'a28', 'a28@admin.com', '2022-01-07 21:00:00', '$2y$10$U/Coxo.n9g6CxriD1Mva2OcTHQJnXj0m8ZBCX6jkbdfEjPoSaTi6i', '7711771771', 'sanaa', 'img_1663512690.png', 'img_1664133432.jpg', 1, 1, 1, 0, 0, 3, 'v4mxmRsnimlYxbkuKVUOpo2jhOP7jw47Hzmfa2y7ohrA44fIKtwy0xnGnWf3', '2022-09-25 16:17:13', '2022-09-25 16:17:13'),
(71, 'a29', 'a29@admin.com', '2022-01-07 21:00:00', '$2y$10$GFz6CGmA2iWvRI0m6q.wsOIQzl7WW0L9KoaWPIckmYfj5A1Bg9Cpu', '7711771771', 'sanaa', 'img_1664133558.jpg', 'img_1664133558.jpg', 1, 1, 1, 0, 0, 3, 'croGdvjmGs1tTAIhYtrm28i43afcgKPYlH7LIutXzMwIiIZ8U65O5sgN7ZaT', '2022-09-25 16:19:18', '2022-09-25 16:19:18'),
(72, 'a30', 'a30@admin.com', '2022-01-07 21:00:00', '$2y$10$iEzIjYp2ok1Qn79vtcq3Guu0A20y67dhhXeVC5IJDKgXkJyV.Q8hO', '7711771771', 'sanaa', 'img_1663512690.png', 'img_card_1663512690.png', 1, 1, 1, 0, 0, 3, '8E9j2ShtJcnzDID79TXtxLu01yby3x1gtHtdMf6LPVDFJ54OrucuKbmEBpgV', '2022-09-25 16:20:52', '2022-09-25 16:20:52'),
(73, 'a31', 'a31@admin.com', '2022-01-07 21:00:00', '$2y$10$tpmN/Rtk2v54qJxUsjNJWex9bXBmfmHKw5AD355Kfx.m.sjFngtAa', '7711771771', 'sanaa', 'img_1664133862.jfif', 'img_1664133862.jpg', 1, 1, 1, 0, 0, 3, 'jip4DePccQWxljou2oA8ci6mta2ctRoOKA0JEEnTlfnUox7zu9RzkEMWKL4B', '2022-09-25 16:24:22', '2022-09-25 16:24:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ads_user_id_foreign` (`user_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mainsettings`
--
ALTER TABLE `mainsettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `msgs`
--
ALTER TABLE `msgs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `type_jobs`
--
ALTER TABLE `type_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mainsettings`
--
ALTER TABLE `mainsettings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `msgs`
--
ALTER TABLE `msgs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `type_jobs`
--
ALTER TABLE `type_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ads`
--
ALTER TABLE `ads`
  ADD CONSTRAINT `ads_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
